package com.example.individualproject.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.individualproject.ItemAdapter

class Tab1Fragment : Fragment() {

//    private lateinit var recyclerView: RecyclerView
//    private lateinit var itemAdapter: ItemAdapter
//
//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        val view = inflater.inflate(R.layout.fragment_tab1, container, false)
//        recyclerView = view.findViewById(R.id.recycler_view)
//        setupRecyclerView()
//        return view
//    }
//
//    private fun setupRecyclerView() {
//        val itemList = listOf("Item 1", "Item 2", "Item 3", "Item 4", "Item 5")
//        itemAdapter = ItemAdapter(itemList)
//        recyclerView.adapter = itemAdapter
//        recyclerView.layoutManager = LinearLayoutManager(context)
//    }
}
