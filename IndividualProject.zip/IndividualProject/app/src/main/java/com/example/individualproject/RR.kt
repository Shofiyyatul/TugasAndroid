package com.example.individualproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class RR : AppCompatActivity{
    override fun onCreate (savedInstanceState: Bundle) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_tab1)

        val names = listOf<String>("Item 1", "Item 2", "Item 3", "Item 4", "Item 5")
        val itemAdapter = ItemAdapter (names)

        findViewById<RecyclerView>(R.id.recycler_view).adapter = itemAdapter
    }
}